# Crie um programa que peça ao usuário seu nome e sobrenome usando input e, em seguida, combine-os para formar uma saudação personalizada.

nome = input("Digite seu nome: ")
sobrenome = input("Digite seu sobrenome: ")

print("Olá", nome, sobrenome, "seja bem-vindo(a)!")